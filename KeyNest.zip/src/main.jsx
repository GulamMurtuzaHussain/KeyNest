import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import ReactDom from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'

ReactDom.createRoot(document.getElementById('root')).render(

    <HashRouter>
    <App />
    </HashRouter>

)
 